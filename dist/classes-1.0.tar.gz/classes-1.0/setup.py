from setuptools import setup

setup(
  name = 'classes',
  version = '1.0',
  description = 'Clases en el paquete: Person',
  author = 'Lautaro Demonte',
  author_email = 'lauty.d.p@gmail.com',

  packages = ['classes']
)